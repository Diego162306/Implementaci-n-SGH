package SistemaGestionHospital;

public interface GestionCitas {
    public void programarcita();

    public void cancelarcita();

    public void realizarcita();

}
